//app.js
// app.js - Versión completa
const express = require('express');
const app = express();
const port = 3000;
const mysql= require('mysql2');//nueva


// Configuración
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

//Conexion con Mysql
const conexion = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'practica_proyecto_final'
});
conexion.connect((err) => {
    if (err) {
        console.error('Error al conectar a la base de datos:', err);
        return;
    }   
    console.log('Conexión a la base de datos establecida');
});

// RUTAS (páginas)
app.get('/', (req, res) => {
    res.render('index', { titulo: 'Inicio' });
});

app.get('/pagina1', (req, res) => {
    res.render('pagina1', { titulo: 'Página 1' });
});

//ruta pagina 2
app.get('/pagina2', (req, res) => {
    conexion.query('SELECT * FROM alumnos', (err, results) => {
        if (err){
            console.error('Error al obtener datos de Mysql: ', err);
            res.render('pagina2',{
                titulo:'Página2',
                alumnos: [],
                error:'No se pudieron cargar los datos de los alumnos'
            });
             return;
        }

        console.log('Datos de alumnos obtenidos:',results);
        res.render('pagina2',{
            titulo:'Página 2',
            alumnos:results,
            error: null
        });
        })
});

app.get('/agregar', (req,res)=> {
   res.render('agregar', {titulo:'agregar alumno'});
});


app.post('/agregar', (req,res) => {
    const {nombre, email, edad, ciudad}=req.body
    const sql = 'INSERT INTO alumnos(nombre,email,edad,ciudad) VALUES  (?,?,?,?)'
    conexion.query(sql,[nombre,email,edad,ciudad], (error) =>{
        if (error){
            console.error("Error al ingresar los datos: ", error);
            res.send('Error al guardar los datos del alumno ')
            return;
        }
        res.redirect('/pagina2');
    });

});

app.get('/editar/:id', (req,res)=>{
    const {id}= req.params;
    const sql  ='SELECT * FROM alumnos WHERE id=?';
    conexion.query(sql, [id], (error, resultados) =>{
        if (error || resultados.length ===0){
            console.error("Error al obtener el alumno: ", error);
            res.send('Alumno no encontrado');
            return;
        }
        res.render('editar',{
            titulo:'Editar alumno',
            alumno: resultados[0]
        });
    });
});

app.post('/editar/:id', (req,res)=>{
    const {id} = req.params;
    const {nombre, email, edad, ciudad} = req.body;
    const sql = 'UPDATE alumnos SET nombre=?, email=?, edad=?, ciudad=? WHERE id=?';
    conexion.query(sql, [nombre, email, edad, ciudad, id], (error)=>{
        if(error){
            console.error("Error al actualizar: ", error);
            res.send('Error al actualizar el alumno');
            return;
        }
        res.redirect('/pagina2');
    });
});

app.get('/eliminar/:id', (req,res)=>{
    const {id} = req.params;
    const sql = 'DELETE FROM alumnos WHERE id=?';
    conexion.query(sql, [id], (error)=>{
        if(error){
            console.error("Error al eliminar: ", error);
            res.send('Error al eliminar el alumno');
            return;
        }
        res.redirect('/pagina2');
    });
});

app.get('/pagina3', (req, res) => {
    conexion.query('SELECT * FROM cursos', (err, results) => {
        if (err){
            console.error('Error al obtener datos de Mysql: ', err);
            res.render('pagina3',{
                titulo:'Página 3',
                cursos: [],
                error:'No se pudieron cargar los cursos'
            });
             return;
        }

        console.log('Datos de cursos obtenidos:',results);
        res.render('pagina3',{
            titulo:'Página 3',
            cursos:results,
            error: null
        });
        })
});
app.get('/pagina4', (req, res) => {
    conexion.query('SELECT * FROM docentes', (err, results) => {
        if (err){
            console.error('Error al obtener datos de Mysql: ', err);
            res.render('pagina4',{
                titulo:'Página 4',
                docentes: [],
                error:'No se pudieron cargar los docentes'
            });
             return;
        }

        console.log('Datos de docentes obtenidos:',results);
        res.render('pagina4',{
            titulo:'Página 4',
            docentes:results,
            error: null
        });
        })
});

app.get('/pagina5', (req, res) => {
    res.render('pagina5', { titulo: 'Página 5' });
});

// Iniciar servidor
app.listen(port, () => {
    console.log(`✅ Servidor listo! Abre http://localhost:${port}`);

});